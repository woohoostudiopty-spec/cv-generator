---
name: ats-cv-generator
description: Generate an ATS-optimized, role-specific CV in DOCX format from a candidate's existing resume and a target job description. Trigger whenever the user provides a CV (any format) plus a job description and asks for a tailored, customized, optimized, or ATS-friendly CV, resume, or curriculum vitae. Also trigger on phrases like "tailor my CV to this job", "optimize my resume for ATS", "customize my CV for this position", "build a CV from my experience for this role", "adapt my resume to this job posting", "rework my resume for this application", or any equivalent in English or Spanish (adaptar, personalizar, optimizar, ajustar, hacer + CV/currículum/hoja de vida). The skill auto-detects output language from the job description (or follows an explicit user override), enforces a strict no-fabrication rule (uses only information present in the candidate's source CV), and produces a single-column, ATS-parseable DOCX. Do NOT use for cover letters, LinkedIn profile rewrites, interview prep, or salary negotiation.
---

# ATS CV Generator

Turns a candidate's existing CV plus a target job description into an ATS-optimized, role-specific DOCX resume. English and Latin American Spanish supported.

## Inputs required

1. **Candidate's source CV** — pasted text, uploaded PDF, DOCX, or markdown.
2. **Target job description** — pasted text or content.
3. **(Optional) Output language override** — `en` or `es`. If omitted, auto-detect from the JD.

If either of the first two is missing, ask for it before generating anything.

## Core rules (non-negotiable)

1. **No fabrication.** Use only experience, skills, tools, dates, certifications, and metrics that appear in the candidate's source CV. Never invent numbers, achievements, or credentials. If a metric is not in the source, do not add one. Reframe instead.
2. **No em dashes** anywhere in the output. Use commas, semicolons, or periods.
3. **Mirror JD terminology exactly.** When the JD uses a specific phrase ("async communication", "stakeholder management", "data pipelines", "comunicación asíncrona"), use that exact phrase if the candidate has matching experience. Do not paraphrase keywords.
4. **ATS-safe formatting only.** Single column, standard section headings, no tables, no text boxes, no graphics, no icons, no skill bars, no text embedded in images.
5. **Outcome-focused bullets.** Every experience bullet follows the formula: `[Action verb] [responsibility] -> [outcome/result] using [tool/method]`.
6. **Honest gaps.** If the candidate clearly lacks a major JD requirement, do not pad the CV to hide it. Surface transferable experience and tell the user about the gap in the summary message.

## Workflow

### Step 1: Read the references
Before generating, view all three:
- `references/ats_rules.md` — structural and formatting rules
- `references/voice_guide.md` — bullet rewriting transformations
- `references/section_formulas.md` — section-by-section templates

### Step 2: Detect output language
- If the user explicitly specified `en` or `es`, use that.
- Otherwise scan the JD. If primarily Spanish, output in Latin American Spanish. If primarily English, output in English.
- If the JD is mixed or unclear, ask the user before proceeding.

### Step 3: Parse the candidate's CV
Extract into a structured record:
- Name, contact info, location, time zone, LinkedIn
- All roles: company, title, dates, location, responsibilities, achievements, metrics
- Skills, tools, technologies, methods
- Education
- Certifications and courses
- Languages and proficiency

Do not invent fields. If something is missing, leave it out.

### Step 4: Parse the JD
Extract:
- Exact job title (use this as the target headline)
- Must-have skills, tools, and platforms (exact phrases)
- Core responsibilities
- Preferred qualifications
- Industry, domain, and methodology keywords
- Remote / hybrid / on-site expectation and time-zone requirements

### Step 5: Map and prioritize
For each candidate role and skill, mark whether it matches a JD requirement. Roles most relevant to the JD get the most bullets and the most prominent placement. Less relevant roles get 2-3 bullets max. Do not delete roles entirely unless space requires it on a one-page layout.

### Step 6: Rewrite to the formulas
- Headline: mirror the target role exactly as the JD names it.
- Summary: 2-3 lines, using the formula in `section_formulas.md`.
- Experience bullets: rewrite each using the outcome formula in `voice_guide.md`.
- Skills: categorize and mirror JD phrasing where the candidate has the skill.
- Surface relevant certifications. Drop ones over 10 years old that are not relevant.

### Step 7: Generate the DOCX

First, ensure the `python-docx` dependency is installed. Run this once per session before calling the script:

```bash
pip install python-docx --quiet --break-system-packages
```

This is idempotent. If the package is already present, the command exits cleanly.

Build the structured data as a Python dict (or JSON file) matching the schema in `examples/sample_data.json`. Then call the generator:

```bash
cd scripts
python build_cv.py --input /tmp/candidate_data.json --output /mnt/user-data/outputs/cv_<role>_<lang>.docx --lang <en|es>
```

Or import directly:

```python
import sys
sys.path.insert(0, '/path/to/ats-cv-generator/scripts')
from build_cv import build_cv
build_cv(data, '/mnt/user-data/outputs/cv_role_en.docx', lang='en')
```

### Step 8: Present and summarize
- Call `present_files` with the DOCX path.
- Add a brief summary (no preamble): target role used, top 3-5 JD keywords matched in the CV, any honest gaps the candidate should know about before applying.
- Do not restate the CV in chat.
- Remind the user they can convert to PDF themselves via Word or Google Docs if the JD requires PDF.

## What this skill does NOT do

- Cover letters (separate task).
- LinkedIn profile rewrites.
- PDF export (user converts the DOCX themselves; any modern editor preserves the single-column layout).
- Live ATS scanning (suggest Resume Worded or Kickresume for the final check).
- Persistent storage of candidate data.

## Failure modes to avoid

- Inventing percentages, dollar amounts, team sizes, or document counts not in the source.
- Using em dashes anywhere.
- Hiding a clear skill gap behind padding instead of surfacing it.
- Paraphrasing a JD keyword that the candidate genuinely has (e.g., writing "remote messaging" when the JD says "async communication").
- Multi-column layouts, tables, icons, or graphics in the DOCX.
- Long preamble in chat instead of just presenting the file.
