#!/usr/bin/env python3
"""
ATS CV Generator - DOCX builder.

Takes structured candidate data (English or Spanish) and produces a
single-column, ATS-parseable DOCX.

CLI usage:
    python build_cv.py --input candidate_data.json --output cv.docx --lang en

Module usage:
    from build_cv import build_cv
    build_cv(data, output_path, lang='en')

Schema: see examples/sample_data.json
"""

import argparse
import json
import sys
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:
    print(
        "Missing dependency: python-docx. Install it with:\n"
        "    pip install python-docx",
        file=sys.stderr,
    )
    sys.exit(1)


# Section labels in supported languages. Add more languages here as needed.
LABELS = {
    "en": {
        "summary": "PROFESSIONAL SUMMARY",
        "experience": "WORK EXPERIENCE",
        "skills": "SKILLS",
        "education": "EDUCATION",
        "certifications": "CERTIFICATIONS",
        "languages": "LANGUAGES",
        "present": "Present",
    },
    "es": {
        "summary": "RESUMEN PROFESIONAL",
        "experience": "EXPERIENCIA LABORAL",
        "skills": "HABILIDADES",
        "education": "EDUCACIÓN",
        "certifications": "CERTIFICACIONES",
        "languages": "IDIOMAS",
        "present": "Presente",
    },
}

DEFAULT_FONT = "Calibri"


def strip_em_dashes(text):
    """Replace em and en dashes with safe punctuation. Safety net for the
    no-em-dashes rule."""
    if not isinstance(text, str):
        return text
    return (
        text.replace("\u2014", ", ")
        .replace("\u2013", "-")
        .replace(" - ", " - ")
    )


def add_heading(doc, text, size=11):
    """Add a section heading. Plain styled paragraph, not Word's Heading styles
    (some ATS parsers handle plain text better)."""
    p = doc.add_paragraph()
    run = p.add_run(text.upper())
    run.bold = True
    run.font.size = Pt(size)
    run.font.name = DEFAULT_FONT
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    return p


def add_text(doc, text, size=10, bold=False, italic=False, align=None, space_after=2):
    """Add a paragraph with plain styled text."""
    text = strip_em_dashes(text)
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = DEFAULT_FONT
    run.bold = bold
    run.italic = italic
    p.paragraph_format.space_after = Pt(space_after)
    if align == "center":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p


def add_bullet(doc, text, size=10):
    """Add a bulleted item using the default List Bullet style."""
    text = strip_em_dashes(text)
    p = doc.add_paragraph(style="List Bullet")
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = DEFAULT_FONT
    p.paragraph_format.space_after = Pt(2)
    return p


def build_header(doc, header):
    """Top contact block. Plain text, centered, single column."""
    if header.get("name"):
        add_text(doc, header["name"], size=16, bold=True, align="center", space_after=2)

    contact_parts = []
    for field in ("email", "phone", "location", "linkedin"):
        val = header.get(field)
        if val:
            contact_parts.append(val)
    if contact_parts:
        add_text(doc, " | ".join(contact_parts), size=10, align="center", space_after=2)

    extras = []
    if header.get("timezone"):
        extras.append(header["timezone"])
    if header.get("remote_status"):
        extras.append(header["remote_status"])
    if header.get("target_role"):
        extras.append(header["target_role"])
    if extras:
        add_text(doc, " | ".join(extras), size=10, italic=True, align="center", space_after=4)


def build_summary(doc, summary, labels):
    if not summary:
        return
    add_heading(doc, labels["summary"])
    add_text(doc, summary, size=10, space_after=4)


def build_experience(doc, experience, labels):
    if not experience:
        return
    add_heading(doc, labels["experience"])
    for role in experience:
        # Title line: Job Title | Company | Location
        title_parts = []
        if role.get("title"):
            title_parts.append(role["title"])
        if role.get("company"):
            title_parts.append(role["company"])
        if role.get("location"):
            title_parts.append(role["location"])
        if title_parts:
            add_text(doc, " | ".join(title_parts), size=11, bold=True, space_after=0)

        # Date line
        start = role.get("start", "")
        end = role.get("end") or labels["present"]
        if start or end:
            add_text(doc, f"{start} - {end}", size=10, italic=True, space_after=2)

        # Bullets
        for bullet in role.get("bullets", []):
            add_bullet(doc, bullet)


def build_skills(doc, skills, labels):
    if not skills:
        return
    add_heading(doc, labels["skills"])
    for category, items in skills.items():
        if not items:
            continue
        # Bold the category label, regular weight for the list
        text = strip_em_dashes(f"{category}: {', '.join(items)}")
        p = doc.add_paragraph()
        label_run = p.add_run(f"{category}: ")
        label_run.bold = True
        label_run.font.size = Pt(10)
        label_run.font.name = DEFAULT_FONT

        items_run = p.add_run(", ".join(items))
        items_run.font.size = Pt(10)
        items_run.font.name = DEFAULT_FONT

        p.paragraph_format.space_after = Pt(2)


def build_education(doc, education, labels):
    if not education:
        return
    add_heading(doc, labels["education"])
    for entry in education:
        line = entry.get("degree", "")
        if entry.get("field"):
            line += f", {entry['field']}"
        if line:
            add_text(doc, line, size=11, bold=True, space_after=0)

        sub_parts = []
        for field in ("institution", "location", "year"):
            val = entry.get(field)
            if val:
                sub_parts.append(str(val))
        if sub_parts:
            add_text(doc, " | ".join(sub_parts), size=10, italic=True, space_after=4)


def build_certifications(doc, certifications, labels):
    if not certifications:
        return
    add_heading(doc, labels["certifications"])

    # Support either a flat list or a dict grouped by category
    if isinstance(certifications, dict):
        for group_name, items in certifications.items():
            if not items:
                continue
            add_text(doc, group_name, size=10, bold=True, space_after=0)
            for cert in items:
                _add_cert_bullet(doc, cert)
    else:
        for cert in certifications:
            _add_cert_bullet(doc, cert)


def _add_cert_bullet(doc, cert):
    parts = []
    if cert.get("name"):
        parts.append(cert["name"])
    if cert.get("issuer"):
        parts.append(cert["issuer"])
    if cert.get("year"):
        parts.append(str(cert["year"]))
    if parts:
        add_bullet(doc, " | ".join(parts))


def build_languages(doc, languages, labels):
    if not languages:
        return
    add_heading(doc, labels["languages"])
    for lang in languages:
        line = f"{lang.get('language', '')}: {lang.get('level', '')}"
        add_text(doc, line, size=10, space_after=2)


def build_cv(data, output_path, lang="en"):
    """Main entry point. Builds a DOCX from structured candidate data.

    Args:
        data: dict matching the schema in examples/sample_data.json
        output_path: where to save the .docx
        lang: 'en' or 'es'

    Returns:
        str path to the saved file.
    """
    if lang not in LABELS:
        raise ValueError(
            f"Unsupported language: {lang!r}. Supported: {list(LABELS.keys())}"
        )

    labels = LABELS[lang]

    doc = Document()

    # ATS-friendly margins
    for section in doc.sections:
        section.top_margin = Inches(0.6)
        section.bottom_margin = Inches(0.6)
        section.left_margin = Inches(0.7)
        section.right_margin = Inches(0.7)

    # Default font on Normal style
    normal = doc.styles["Normal"]
    normal.font.name = DEFAULT_FONT
    normal.font.size = Pt(10)

    # Build sections in the standard ATS order
    build_header(doc, data.get("header", {}))
    build_summary(doc, data.get("summary", ""), labels)
    build_experience(doc, data.get("experience", []), labels)
    build_skills(doc, data.get("skills", {}), labels)
    build_education(doc, data.get("education", []), labels)
    build_certifications(doc, data.get("certifications", []), labels)
    build_languages(doc, data.get("languages", []), labels)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(output_path))
    return str(output_path)


def main():
    parser = argparse.ArgumentParser(description="ATS CV Generator")
    parser.add_argument("--input", required=True, help="Path to JSON file with candidate data")
    parser.add_argument("--output", required=True, help="Path to output DOCX file")
    parser.add_argument("--lang", default="en", choices=sorted(LABELS.keys()), help="Output language")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    path = build_cv(data, args.output, args.lang)
    print(f"CV generated at: {path}")


if __name__ == "__main__":
    main()
