# Voice and Bullet Rewriting Guide

The single biggest difference between a generic CV and one that converts: outcome-focused bullets that prove ownership and result.

## The blueprint formula

```
[Action verb] [specific responsibility] -> [outcome or qualified result] using [tool/method/context]
```

Apply it to every experience bullet. If the candidate's source CV does not include a specific outcome, do not invent one. Reframe the bullet using scope, method, stakeholders, or constraints instead. See the "When the source CV has no metric" section below.

## Before and after patterns (generic illustrations)

These use placeholders so you can see the transformation pattern without anchoring on a specific industry. Replace placeholders with the candidate's verified information.

### Pattern 1: Generic responsibility -> owned outcome

**Before:** Responsible for managing [system/area].
**After:** Owned [scope of work] across [audience or team], improving [outcome type] using [tool or method].

### Pattern 2: Vague collaboration -> concrete coordination

**Before:** Worked with team members on various projects.
**After:** Coordinated [task type] across a distributed [N]-person team using [collaboration tools] to maintain [outcome].

### Pattern 3: Task list -> process and result

**Before:** Created [document type / deliverable].
**After:** Architected and maintained [type of deliverable] for [system or audience], enhancing [outcome] through [method].

### Pattern 4: Soft claim -> proof of regulatory or compliance ownership

**Before:** Helped with compliance submissions.
**After:** Submitted [count or scope] regulated compliance [documents/filings] to [regulator/body], achieving [approval/result] under [conditions: deadline, audit, etc.].

### Pattern 5: Implementation as orchestration

**Before:** Helped implement new software.
**After:** Led [design / migration / deployment / training] phase for [software/platform], coordinating with [stakeholder groups] to deliver [outcome].

### Pattern 6: "Improved" -> measurable or scoped impact

**Before:** Improved team productivity.
**After:** Standardized [process / workflow / template], reducing [bottleneck type] for a team of [N] across [function/region].

### Pattern 7: Generic leadership -> evidence of decision rights

**Before:** Managed a team.
**After:** Led a team of [N] across [functions/locations], setting [process/standards] and owning [outcome type] including [specific example].

## When the source CV has no metric

Do not invent a number. Lean on these dimensions instead, drawing only from facts the candidate has confirmed:

- **Scope:** number of people, projects, documents, clients, locations, languages, countries
- **Method:** tool, framework, process, methodology (Agile, Lean, etc.)
- **Stakeholders:** who the work coordinated with (Engineering, QA, Legal, Product, C-suite, regulators)
- **Constraints:** regulatory, deadline, cross-functional, multi-time-zone, multi-language
- **Recurrence:** daily, weekly, monthly, ongoing
- **Complexity:** integrations involved, systems migrated, languages supported, jurisdictions covered

**Example reframe without invented numbers:**

Owned weekly documentation reviews across engineering, QA, and product, ensuring consistent terminology and version control for a regulated software platform.

This bullet has zero invented metrics but still demonstrates ownership, scope, stakeholder coordination, and domain context.

## Verb bank

**Leadership:** Led, Directed, Owned, Drove, Spearheaded, Orchestrated, Coordinated, Headed, Supervised
**Building:** Built, Designed, Developed, Architected, Implemented, Deployed, Migrated, Launched, Established, Created
**Improving:** Optimized, Streamlined, Reduced, Increased, Improved, Standardized, Automated, Refactored, Consolidated
**Communicating:** Documented, Translated, Trained, Advised, Aligned, Presented, Negotiated, Briefed, Facilitated
**Analyzing:** Analyzed, Audited, Evaluated, Reviewed, Researched, Measured, Benchmarked, Investigated

**Spanish equivalents:** Lideré, Dirigí, Diseñé, Implementé, Desarrollé, Migré, Optimicé, Reduje, Aumenté, Estandaricé, Automaticé, Documenté, Coordiné, Capacité, Analicé, Audité.

## Avoid

- "Responsible for..." (passive, weak)
- "Helped with..." (no ownership)
- "Various" or "many" (vague)
- "Successful" without saying what success was
- Em dashes anywhere
- Repeating the same verb three times within one role
- Bullets longer than two lines
- Buzzwords without backing ("synergy", "thought leader", "ninja", "guru", "rockstar")
- Personal pronouns ("I", "we", "my") in bullets
- Articles at the start of bullets ("The", "A") when a verb works better
