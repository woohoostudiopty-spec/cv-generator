# ATS Formatting Rules

These rules ensure the generated DOCX passes Applicant Tracking System parsing without losing content.

## Structural rules

1. **Single-column layout only.** ATS reads left to right. Multi-column templates scramble content.
2. **Standard section headings.** Use exactly these labels:
   - English: `PROFESSIONAL SUMMARY`, `WORK EXPERIENCE`, `SKILLS`, `EDUCATION`, `CERTIFICATIONS`, `LANGUAGES`
   - Spanish: `RESUMEN PROFESIONAL`, `EXPERIENCIA LABORAL`, `HABILIDADES`, `EDUCACIÓN`, `CERTIFICACIONES`, `IDIOMAS`
3. **No tables, text boxes, or graphics in the body.** No icons, skill bars, progress circles, charts, or decorative elements.
4. **No text inside images.** ATS cannot read pixels. All text must be selectable.
5. **Standard fonts only.** Calibri, Arial, or Times New Roman. Body text 10-11pt, name 14-16pt, section headings 11-12pt bold.
6. **File format.** Output as `.docx`. The user converts to PDF themselves if the JD requires it.
7. **No headers or footers** holding contact info. Place contact info in the top body of the document so the parser captures it.

## Content rules

8. **Match exact JD terminology.** If the JD says "stakeholder management", do not write "people coordination". If the JD says "async communication", do not write "remote messaging".
9. **No keyword stuffing.** Keywords must appear naturally inside experience bullets and the skills section. Never as hidden white text or block-pasted strings.
10. **Strategic keyword placement.** Each priority keyword should appear in at least two places: the Skills section and at least one experience bullet.
11. **Action verbs lead every bullet.** Past tense for past roles, present tense for current roles. Verbs like Led, Built, Designed, Implemented, Owned, Architected, Migrated, Reduced, Increased, Coordinated.

## Length and structure

12. **Length.** One page for under 10 years of experience. Two pages maximum for senior profiles. Never more than two.
13. **Order of sections.**
    1. Header (name, contact, location and time zone, target role indicator)
    2. Professional Summary
    3. Work Experience (reverse chronological)
    4. Skills
    5. Education
    6. Certifications
    7. Languages (if relevant)
14. **Date format.** `Month YYYY - Month YYYY` or `Month YYYY - Present`. Consistent throughout.
15. **Reverse chronological order** for experience and education.

## Punctuation and formatting

16. **No em dashes anywhere.** Use commas, semicolons, or periods. The build script auto-strips em dashes and en dashes as a safety net.
17. **No unicode bullets or special characters.** Use the default Word bullet style only.
18. **No emojis.**
19. **Plain capitalization.** Do not use ALL CAPS except in section headings, consistently.
20. **No italics or bold for emphasis inside paragraphs.** Bold is reserved for job titles, company names, and section headings.

## Header rules

21. **Location and time zone** belong in the header, especially for remote roles. Format: `City, Country (GMT-X)` or `City, Country (EST)`.
22. **LinkedIn URL** should be the customized vanity URL, not the default `linkedin.com/in/abc-1234567890`.
23. **No photo, age, marital status, or nationality** in the header unless the country's job market expects it.
24. **No physical street address.** City and country are enough.
25. **Remote / hybrid / on-site availability** can be included as a one-line indicator if relevant to the role.

## Pre-submission checklist

Before delivering the file, confirm:
- [ ] Single column throughout
- [ ] Standard section headings in the correct order
- [ ] No tables, graphics, icons, or text boxes
- [ ] No em dashes
- [ ] Headline mirrors the target role
- [ ] At least 3-5 JD keywords appear in both Skills and Experience
- [ ] Date format consistent
- [ ] Length within one or two pages
- [ ] No fabricated metrics or credentials
