# Section-by-Section Formulas

Use these templates as the structure for every CV the skill generates. All placeholders in `[brackets]` must be replaced with the candidate's verified information from their source CV.

## 1. Header

**English formula:**
```
[Full Name]
[Email] | [Phone] | [City, Country] ([Time Zone])
[LinkedIn vanity URL]
[Optional: Open to Remote / Hybrid / On-site]
```

**Spanish formula:**
```
[Nombre Completo]
[Correo] | [Teléfono] | [Ciudad, País] ([Zona Horaria])
[LinkedIn URL]
[Opcional: Disponible para Remoto / Híbrido / Presencial]
```

Notes:
- Include time zone if applying to remote roles in another region.
- LinkedIn URL should be the vanity URL, not the default numeric one.
- Do not include a physical street address, photo, age, marital status, or nationality unless the country's job market expects it.

## 2. Professional Summary

**English formula (2-3 lines):**
```
[Target role from JD] with [N+] years of experience in [domain/industries from candidate's background]. Proven track record of [outcome type relevant to JD] and [second strength relevant to JD]. Skilled in [3-5 top JD keywords that the candidate actually has].
```

**Spanish formula (2-3 lines):**
```
[Rol objetivo de la oferta] con [N+] años de experiencia en [dominio/industrias]. Trayectoria comprobada en [tipo de resultado] y [segunda fortaleza]. Experto/a en [3-5 palabras clave principales de la oferta].
```

Rules:
- Mirror the target role exactly as the JD names it.
- Pull 3-5 keywords directly from the JD, but only ones the candidate genuinely matches.
- Never write vague aspirational statements ("Seeking a role where I can grow").
- Never write the candidate's current title if the target role is different. Use the target role.

## 3. Work Experience

**Per-role structure:**

```
[Job Title] | [Company] | [City, Country or Remote]
[Month YYYY] - [Month YYYY or Present]

- [Outcome bullet 1 using voice_guide.md formula]
- [Outcome bullet 2]
- [Outcome bullet 3]
- [Outcome bullet 4 if highly relevant role]
- [Outcome bullet 5 if highly relevant role]
- [Outcome bullet 6 if highly relevant role]
```

Rules:
- Reverse chronological order.
- Most relevant roles to the JD get 4-6 bullets. Less relevant roles get 2-3 bullets max. Very old or off-topic roles can be reduced to a single summary line.
- For freelance or self-employed periods, name the entity ("Independent Consultant" or the brand) and optionally list client industries.
- Promotions inside the same company: list as separate entries to show progression.
- Job titles can be slightly reframed to match standard market terminology (e.g., "Stock Brokerage Operations Manager" can become "Operations Manager, Capital Markets" if more standard) only if the new title accurately describes the work done. Do not invent titles the candidate did not hold.

## 4. Skills

**Formula:**
```
[Category 1]: [comma-separated keywords]
[Category 2]: [comma-separated keywords]
[Category 3]: [comma-separated keywords]
```

Standard categories (pick what applies, in this rough order of relevance):
- Technical Skills / Habilidades Técnicas
- Tools and Platforms / Herramientas y Plataformas
- Methods and Processes / Métodos y Procesos
- Remote Collaboration Tools / Herramientas de Colaboración Remota
- Domain Expertise / Experiencia de Dominio
- AI and Automation / IA y Automatización

Rules:
- Mirror the JD's exact phrasing where the candidate has the skill.
- Group remote-work tools explicitly (Slack, Notion, Jira, Asana, Git, Confluence) if the role is remote and the candidate uses them.
- Do not pad with skills the candidate does not have.
- Lead each category with the keywords most relevant to the JD.

## 5. Education

**Formula:**
```
[Degree], [Field of Study]
[Institution] | [City, Country] | [Year]
```

Rules:
- Most recent first.
- Omit GPA unless above 3.5 and graduated within the last 5 years.
- Do not list high school if the candidate has a bachelor's or higher.
- Foreign degrees: keep the original institution name and country.

## 6. Certifications

**Formula:**
```
[Certification or course name] | [Issuing organization] | [Year]
```

Rules:
- Group by relevance to the JD when there are many. Subgroup with mini-headings if useful: "AI and Technology", "Marketing", "Project Management".
- Most recent or most relevant first.
- Drop certifications over 10 years old that are not relevant to the target role.
- Do not list every course the candidate ever attended. Curate to 5-12 of the most relevant.

## 7. Languages (separate section if multiple)

**Formula:**
```
[Language]: [Proficiency level]
```

Proficiency labels: Native, Fluent, Professional, Conversational, Basic.
Spanish equivalents: Nativo, Fluido, Profesional, Conversacional, Básico.

Rules:
- Only list languages the candidate can actually work in.
- For Spanish-language CVs, this section often appears more prominently.
- If the role explicitly requires bilingual capability, surface this in the summary too.
